const Charter = () => {
  return <div>Charter</div>;
};

export default Charter;
