import { Button } from "react-bootstrap";

 

const Transport = () => {
  return (
    <>
      <div className="h1 mt-5">Transport</div>
     
    </>
  );
};

export default Transport;
