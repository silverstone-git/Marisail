const Berths = () => {
  return <div>Berths</div>;
};

export default Berths;
