const Sell = () => {
  return <div>Sell</div>;
};

export default Sell;
