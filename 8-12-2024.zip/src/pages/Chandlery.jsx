const Chandlery = () => {
  return <div>Chandlery</div>;
};

export default Chandlery;
