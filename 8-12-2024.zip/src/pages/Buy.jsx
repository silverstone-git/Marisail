const Buy = () => {
  return <div>Buy</div>;
};

export default Buy;
